# CyxWiz Data Studio — Complete Stratified Architecture
## The ML Engineer's Complete Data Preparation Environment

**Design Philosophy:** Mirror KNIME's proven layer architecture but purpose-built for ML workflows across all modalities (image, audio, text, video, tabular, time-series).

---

## 🎯 Core Design Principle

CyxWiz Data Studio is NOT a data analytics tool that happens to prepare ML data.  
It IS a ML data engineering platform that follows KNIME's organizational principles.

**What this means:**
- Every layer is designed with model training as the destination
- Every modality (image/audio/text/video/tabular/time-series) is first-class from Day 1
- Every pipeline produces training-ready outputs with correct shapes, dtypes, splits
- Direct integration with the Node Editor — no export/import friction

---

## 📚 The Seven-Layer Architecture

Based on KNIME's proven structure, adapted for ML:

```
┌──────────────────────────────────────────────────────────────────────┐
│  LAYER 7 — Deployment & Training Integration                         │
│  • Model handoff          • Remote training      • Pipeline export    │
└──────────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────────┐
│  LAYER 6 — Annotation & Labeling (ML-Specific)                       │
│  • Bounding boxes         • Segmentation masks   • Classification     │
└──────────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────────┐
│  LAYER 5 — Visualization & Inspection                                │
│  • Charts                 • Media viewers        • Distribution plots │
└──────────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────────┐
│  LAYER 4 — Analysis & Profiling                                      │
│  • Statistics             • Quality scoring      • Anomaly detection  │
└──────────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────────┐
│  LAYER 3 — Transformation & Feature Engineering                      │
│  • Pipeline DAG           • Processing nodes     • Feature extraction │
└──────────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────────┐
│  LAYER 2 — Data Registry & Version Control                           │
│  • Dataset catalog        • Lineage tracking     • Version management │
└──────────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────────┐
│  LAYER 1 — Data Access & Ingestion                                   │
│  • File loaders           • Database connectors  • Streaming sources  │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 🔹 LAYER 1 — Data Access & Ingestion

**Purpose:** Universal data loading across all sources and formats

### Components

#### 1.1 Universal Data Loader
```cpp
class UniversalDataLoader {
    static Dataset* Load(const DataSource& source);
    
    // Source types
    - LocalFile          (CSV, JSON, Parquet, NPZ, HDF5)
    - CloudStorage       (CyxCloud S3, AWS S3, GCS, Azure Blob)
    - Database           (DuckDB, PostgreSQL, MySQL, MongoDB)
    - StreamingSource    (Kafka, RabbitMQ, MQTT)
    - APIEndpoint        (REST, GraphQL, gRPC)
    - PluginSource       (IDataProvider interface)
};
```

#### 1.2 Format-Specific Loaders (Per Modality)

**Tabular Data:**
- CSV (DuckDB streaming for large files)
- Parquet (Arrow columnar)
- Excel (SheetJS / OpenXML)
- SQL query results (via DuckDB/JDBC)

**Images:**
- Standard formats: JPEG, PNG, TIFF, BMP, WebP, GIF
- Medical: DICOM (via DCMTK or pydicom bridge)
- Scientific: HDF5 multi-dimensional arrays
- Compressed archives: ZIP, TAR with lazy extraction

**Audio:**
- WAV, MP3, FLAC, OGG, M4A, AAC
- Via libsndfile + FFmpeg fallback
- Chunked loading for long files

**Video:**
- MP4, AVI, MOV, MKV, WebM
- Via FFmpeg frame extraction
- Scene detection for segmentation
- Thumbnail extraction for preview

**Text:**
- TXT, Markdown, HTML (strip tags)
- JSON (structured/nested)
- PDF (via pdftotext or pypdf2)
- Office docs (docx/pptx via python-docx/python-pptx)

**Time-Series:**
- TSV/CSV with timestamp column
- Parquet with temporal index
- InfluxDB / TimescaleDB connectors
- MQTT live streams

#### 1.3 Schema Inference Engine
```cpp
class SchemaInferenceEngine {
    DataSchema InferSchema(const RawData& data);
    
    // Infers:
    - Column data types (int, float, string, datetime, categorical)
    - Image dimensions & color space
    - Audio sample rate & channels
    - Video frame rate & resolution
    - Text encoding & language
    - Missing value patterns
};
```

#### 1.4 Plugin Data Providers
```cpp
class IDataProvider {
    virtual bool CanHandle(const URI& source) = 0;
    virtual Dataset* Load(const URI& source) = 0;
    virtual DataPreview GetPreview(const URI& source) = 0;
};

// Examples of plugin providers:
- DICOMDataProvider        (medical imaging PACS servers)
- LidarDataProvider        (point cloud PCD/PLY files)
- BioSequenceProvider      (FASTA/GenBank sequences)
- SatelliteImageProvider   (GeoTIFF with coordinate systems)
- FinancialDataProvider    (Bloomberg/Reuters tick data)
```

---

## 🔹 LAYER 2 — Data Registry & Version Control

**Purpose:** Unified catalog and version tracking for all datasets and transformations

### Components

#### 2.1 DataRegistry — The Core Catalog
```cpp
class DataRegistry {
    // Singleton instance
    static DataRegistry& Instance();
    
    // Core operations
    DatasetHandle Register(const Dataset& data, const Metadata& meta);
    Dataset* Get(const string& dataset_id, const string& version = "latest");
    vector<DatasetHandle> List(const Filter& filter);
    bool Delete(const string& dataset_id, const string& version);
    
    // Version operations
    DatasetHandle CreateVersion(const string& dataset_id, const string& tag);
    vector<string> ListVersions(const string& dataset_id);
    Dataset* GetVersion(const string& dataset_id, const string& version);
    
    // Lineage tracking
    LineageGraph GetLineage(const string& dataset_id);
    vector<Dataset*> GetDerivedDatasets(const string& parent_id);
};
```

#### 2.2 Dataset Metadata Schema
```cpp
struct DatasetMetadata {
    string id;                    // Unique identifier (UUID)
    string name;                  // Human-readable name
    string version;               // Semantic version or hash
    Modality modality;            // IMAGE, AUDIO, TEXT, VIDEO, TABULAR, TIMESERIES
    
    // Physical properties
    DataShape shape;              // [N, C, H, W] or [N, T, F] etc.
    DataType dtype;               // float32, uint8, int64, string
    size_t num_samples;
    size_t size_bytes;
    
    // Storage
    StorageLocation location;     // Local path, S3 URI, database table
    CompressionType compression;  // None, gzip, lz4, zstd
    
    // Provenance
    string parent_dataset_id;     // Source dataset
    string pipeline_id;           // Transformation pipeline that created this
    vector<string> transformation_history;
    
    // Quality metrics
    float quality_score;          // 0-100 data quality score
    map<string, float> statistics; // Mean, std, null rate, etc.
    
    // ML-specific
    SplitInfo splits;             // train/val/test row indices
    ClassBalance class_distribution;
    
    // Temporal
    timestamp created_at;
    timestamp modified_at;
    string created_by;            // User or system ID
};
```

#### 2.3 Lineage Tracking
```cpp
class LineageTracker {
    // Track data provenance
    void RecordTransformation(
        const string& input_dataset_id,
        const string& output_dataset_id,
        const string& pipeline_id,
        const json& parameters
    );
    
    // Query lineage
    LineageGraph GetUpstreamLineage(const string& dataset_id);   // Parents
    LineageGraph GetDownstreamLineage(const string& dataset_id); // Children
    
    // Blockchain integration point
    string GetLineageHash(const string& dataset_id);
    void PublishLineageToChain(const string& dataset_id);
};
```

#### 2.4 Version Control Strategy
```
Dataset Versions:
├── v1.0        (original)
├── v1.1        (after cleaning)
├── v1.2        (after augmentation)
├── v2.0-train  (train split)
├── v2.0-val    (validation split)
└── v2.0-test   (test split)

Version Tags:
- Semantic: v1.0, v1.1, v2.0
- Descriptive: cleaned, augmented, normalized
- Git-style: abc123de (content hash)
- Temporal: 2026-02-25T14:30:00Z
```

---

## 🔹 LAYER 3 — Transformation & Feature Engineering

**Purpose:** The pipeline DAG where all data processing happens

### 3.1 The Node System Architecture

#### Base Node Interface
```cpp
class DSNode {
    virtual string GetTypeID() const = 0;
    virtual string GetCategory() const = 0;
    virtual string GetDisplayName() const = 0;
    
    virtual vector<DSPort> GetInputPorts() const = 0;
    virtual vector<DSPort> GetOutputPorts() const = 0;
    
    virtual DSResult Execute(
        const DSPortData& inputs,
        const json& config,
        ProgressCallback progress
    ) = 0;
    
    virtual void RenderConfig(json& config) = 0;
    virtual json DefaultConfig() const = 0;
    virtual json ValidateConfig(const json& config) const = 0;
};
```

#### Port Type System
```cpp
enum class PortType {
    TABLE,        // Tabular data (DataFrame equivalent)
    IMAGE,        // Single image or batch
    AUDIO,        // Audio waveform
    VIDEO,        // Video frame sequence
    TEXT,         // Text corpus
    TIMESERIES,   // Time-indexed numeric data
    EMBEDDING,    // Dense vector representation
    ANNOTATION,   // Labels, bboxes, masks
    MODEL,        // Trained model object
    GENERIC       // Any Python object
};
```

### 3.2 Complete Node Catalogue by Modality

#### TABULAR NODES (15 nodes)
```
Input:
├── FileInput           (CSV, Parquet, Excel, JSON)
├── DatabaseQuery       (SQL against DuckDB/Postgres/MySQL)
└── CloudImport         (CyxCloud, S3, GCS)

Cleaning:
├── FilterRows          (SQL WHERE clause or Python lambda)
├── SelectColumns       (Column subset selection)
├── FillMissing         (mean/median/mode/forward-fill/interpolate)
├── RemoveDuplicates    (exact or fuzzy matching)
└── TypeCast            (change dtypes, parse dates)

Joining & Merging:
├── JoinDatasets        (SQL join types: inner/outer/left/right)
├── ConcatDatasets      (vertical/horizontal concatenation)
└── Pivot               (Reshape wide ↔ long format)

Aggregation:
├── GroupBy             (SQL GROUP BY with agg functions)
└── WindowFunction      (Rolling/expanding/EWM operations)

Feature Engineering:
├── OneHotEncode        (Categorical → binary columns)
└── LabelEncode         (Categorical → integer codes)
```

#### TEXT NODES (12 nodes)
```
Cleaning:
├── TextClean           (Remove HTML, URLs, special chars, normalize)
├── TextNormalize       (Lowercase, unicode normalization, strip)
└── RemoveStopwords     (Language-specific stopword removal)

Tokenization:
├── Tokenize            (Word/whitespace/char/subword)
├── Stem                (Porter/Snowball stemmer)
├── Lemmatize           (WordNet lemmatization)
└── SentenceSegment     (Split into sentences)

Feature Extraction:
├── NGrams              (Bigrams, trigrams, n-grams)
├── TFIDF               (Term frequency–inverse document frequency)
├── BagOfWords          (Count vectorization)
└── CharacterNGrams     (Character-level n-grams)

Embedding:
├── WordEmbedding       (FastText/GloVe lookup)
└── SentenceEmbedding   (Sentence transformers)
```

#### IMAGE NODES (14 nodes)
```
Loading & Basic:
├── ImageLoad           (Batch load from folder)
├── ImageResize         (Fixed size, aspect-preserving, padding)
├── ImageCrop           (Center, random, coordinates)
└── ImageRotate         (Fixed angle, random, auto-orient)

Color & Normalization:
├── ImageNormalize      (Mean/std normalization, [0,1] scaling)
├── ColorSpaceConvert   (RGB↔BGR↔HSV↔LAB↔Grayscale)
├── HistogramEqualize   (CLAHE, global equalization)
└── Denoise             (Gaussian blur, bilateral filter, NLM)

Augmentation:
├── ImageAugment        (13 presets: flip, rotate, brightness, contrast, etc.)
├── RandomCrop          (Training augmentation)
├── Cutout              (Random occlusion for robustness)
└── Mixup               (Blend two images for regularization)

Quality & Filtering:
├── BlurDetection       (Laplacian variance threshold)
└── DuplicateDetection  (pHash/aHash/dHash perceptual hashing)
```

#### AUDIO NODES (11 nodes)
```
Loading & Conversion:
├── AudioLoad           (Batch load from folder)
├── AudioResample       (Change sample rate)
├── AudioTrim           (Start/end trimming, silence removal)
└── AudioNormalize      (Peak normalization, RMS normalization)

Feature Extraction:
├── MFCC                (Mel-frequency cepstral coefficients)
├── MelSpectrogram      (Mel-scaled spectrogram)
├── Spectrogram         (Short-time Fourier transform)
├── ChromaFeatures      (Pitch class features)
└── SpectralFeatures    (Centroid, rolloff, flux)

Augmentation:
├── TimeStretch         (Speed up/slow down without pitch change)
└── PitchShift          (Change pitch without speed change)
```

#### VIDEO NODES (8 nodes)
```
Loading & Extraction:
├── VideoLoad           (Load video file)
├── FrameExtract        (Extract frames at intervals/keyframes)
├── SceneDetect         (Detect scene boundaries)
└── VideoResize         (Resize all frames)

Processing:
├── OpticalFlow         (Compute motion vectors)
├── FrameSample         (Uniform/random frame sampling)
├── VideoTrim           (Temporal trimming)
└── FrameRate           (Change FPS)
```

#### TIME-SERIES NODES (10 nodes)
```
Windowing:
├── TSWindow            (Sliding window with overlap)
├── TSRolling           (Rolling mean/std/max/min)
└── TSExpanding         (Expanding window statistics)

Feature Engineering:
├── TSFeatures          (Statistical features per window)
├── TSLag               (Create lagged features)
├── TSDiff              (First/second difference)
└── TSDetrend           (Remove linear/polynomial trend)

Splitting:
├── TSSplit             (Train/val/test temporal split)
├── TSGroupSplit        (Split by entity ID, preserve time order)
└── TSStratifiedSplit   (Stratified by class within time windows)
```

#### FEATURE ENGINEERING NODES (8 nodes)
```
Scaling:
├── StandardScale       (Z-score normalization)
├── MinMaxScale         (Scale to [0,1] or [a,b])
└── RobustScale         (Median/IQR scaling, outlier-resistant)

Dimensionality Reduction:
├── PCA                 (Principal component analysis)
├── UMAP                (Uniform manifold approximation)
└── TruncatedSVD        (For sparse matrices)

Selection:
├── FeatureSelect       (Variance threshold, correlation filter)
└── TargetEncoding      (Mean encoding for categoricals)
```

#### OUTPUT NODES (6 nodes)
```
├── SaveDataset         (Register in DataRegistry with version)
├── ExportFile          (CSV, Parquet, NPZ, TFRecord, HDF5)
├── CloudUpload         (Upload to CyxCloud with metadata)
├── ExportAnnotations   (COCO, YOLO, VOC, CyxWiz native)
├── ExportTraining      (Direct handoff to Node Editor)
└── ExportPipeline      (Save pipeline as JSON template)
```

### 3.3 Pipeline Execution Engine
```cpp
class PipelineExecutor {
    // Execute entire pipeline
    PipelineResult Execute(const Pipeline& pipeline);
    
    // Execute single node (for debugging)
    NodeResult ExecuteNode(
        const DSNode* node,
        const DSPortData& inputs,
        const json& config
    );
    
    // Parallel execution strategies
    ExecutionMode mode;  // SEQUENTIAL, PARALLEL, GPU_BATCHED
    
    // Progress tracking
    void SetProgressCallback(ProgressCallback callback);
    
    // Error handling
    ErrorStrategy error_strategy;  // STOP, SKIP, RETRY
};
```

### 3.4 Memory Management Strategy
```cpp
class DataRegistry {
    // LRU cache for intermediate results
    size_t max_memory_mb = 8192;  // Configurable
    LRUCache<string, Dataset*> cache;
    
    // Eviction policy
    void EvictLRU();
    
    // Disk spillover for large datasets
    void SpillToDisk(const string& dataset_id);
    Dataset* LoadFromDisk(const string& dataset_id);
};
```

---

## 🔹 LAYER 4 — Analysis & Profiling

**Purpose:** Automated data quality assessment and statistical profiling

### 4.1 Automated Profiler (Existing: dataset_analyzer.cpp)
```cpp
class DatasetAnalyzer {
    ProfileReport Analyze(const Dataset& dataset);
    
    struct ProfileReport {
        // Per-column statistics
        map<string, ColumnStats> column_statistics;
        
        // Data quality
        float overall_quality_score;
        vector<QualityIssue> issues;
        
        // Correlation analysis
        Matrix correlation_matrix;
        
        // Class balance (for supervised learning)
        map<string, int> class_distribution;
        float imbalance_ratio;
        
        // Outlier detection
        vector<OutlierRecord> outliers;
        
        // Recommendations
        vector<string> recommendations;
    };
};
```

### 4.2 Modality-Specific Analysis

#### Tabular Analysis
```
- Descriptive statistics: mean, median, std, min, max, quartiles
- Null value rate and patterns
- Cardinality: unique values, most frequent values
- Data type consistency
- Correlation matrix (numeric columns)
- Class imbalance detection
- Outlier detection (IQR, Z-score, Isolation Forest)
```

#### Image Analysis
```
- Resolution distribution
- Aspect ratio distribution
- Color space statistics
- Brightness/contrast histograms
- Blur detection (Laplacian variance)
- Duplicate detection (perceptual hashing)
- Quality scoring: sharp, well-exposed, in-focus
```

#### Audio Analysis
```
- Sample rate distribution
- Duration statistics
- Silence ratio
- Clipping detection
- SNR (signal-to-noise ratio) estimation
- Dynamic range
- Spectral analysis
```

#### Text Analysis
```
- Document length distribution
- Vocabulary size
- Most frequent words
- Language detection
- Encoding consistency
- Special character frequency
- Sentiment distribution (if applicable)
```

### 4.3 DuckDB Query Editor
```cpp
class QueryEditor {
    // Execute arbitrary SQL against any dataset
    QueryResult ExecuteSQL(
        const string& dataset_id,
        const string& sql_query
    );
    
    // Save query result as new dataset
    DatasetHandle SaveQueryResult(
        const string& name,
        const QueryResult& result
    );
    
    // Query templates
    vector<string> GetQueryTemplates();
};
```

---

## 🔹 LAYER 5 — Visualization & Inspection

**Purpose:** Interactive visual inspection of data at any pipeline stage

### 5.1 Visualization Manager
```cpp
class VisualizationManager {
    // Chart rendering (via ImPlot)
    void RenderHistogram(const Dataset& data, const string& column);
    void RenderScatterPlot(const Dataset& data, const string& x, const string& y);
    void RenderLinePlot(const Dataset& data, const string& x, const string& y);
    void RenderBoxPlot(const Dataset& data, const vector<string>& columns);
    void RenderHeatmap(const Matrix& correlation_matrix);
    void RenderDistribution(const Dataset& data, const string& column);
    
    // Media viewers
    void ShowImageGallery(const ImageDataset& images);
    void ShowAudioWaveform(const AudioDataset& audio);
    void ShowVideoFrameStrip(const VideoDataset& video);
    void ShowTextSample(const TextDataset& text);
};
```

### 5.2 Media Viewers

#### Image Gallery
```
- Thumbnail grid (configurable size)
- Pagination / infinite scroll
- Click for full-screen view
- Side-by-side before/after comparison
- Augmentation preview overlay
- Metadata overlay (dimensions, file size, class label)
- Zoom/pan controls
```

#### Audio Waveform Viewer
```
- Time-domain waveform
- Frequency-domain spectrogram overlay
- MFCC coefficient visualization
- Playback controls (play/pause/seek)
- Segment selection for trimming
- Amplitude/frequency cursors
```

#### Video Frame Strip
```
- Horizontal frame strip (like a film reel)
- Scene boundary markers
- Frame-level navigation
- Optical flow visualization toggle
- Playback controls
- Frame extraction tool
```

#### Text Document Viewer
```
- Paginated text display
- Syntax highlighting (for code/JSON)
- Token boundary visualization
- Named entity highlighting
- Sentiment color-coding
- Search and filter
```

### 5.3 Distribution Comparisons
```cpp
// Compare train/val/test split distributions
void CompareDistributions(
    const Dataset& train,
    const Dataset& val,
    const Dataset& test,
    const string& column
);

// Class balance across splits
void ShowClassBalance(
    const ClassBalance& train_balance,
    const ClassBalance& val_balance,
    const ClassBalance& test_balance
);

// Temporal distribution for time-series
void ShowTemporalDistribution(
    const TimeSeriesDataset& data,
    const string& time_column
);
```

---

## 🔹 LAYER 6 — Annotation & Labeling (ML-Specific)

**Purpose:** Supervised learning annotation workflow

### 6.1 Annotation Manager (Existing: annotation_manager.h)
```cpp
class AnnotationManager {
    // Tool types
    enum class ToolType {
        BOUNDING_BOX,
        POLYGON,
        SEMANTIC_MASK,
        POINT_CLOUD,
        POLYLINE,
        CLASSIFICATION_LABEL
    };
    
    // Core operations
    void AddAnnotation(const Annotation& annotation);
    void EditAnnotation(const AnnotationID& id, const Annotation& new_ann);
    void DeleteAnnotation(const AnnotationID& id);
    vector<Annotation> GetAnnotations(const SampleID& sample_id);
    
    // Batch operations
    void ApplyToAll(const LambdaFunction& func);
    void BulkClassChange(const string& old_class, const string& new_class);
    
    // Navigation
    void NextSample();
    void PrevSample();
    void GoToSample(int index);
    
    // Class management
    void AddClass(const string& name, const Color& color);
    void RenameClass(const string& old_name, const string& new_name);
    void MergeClasses(const vector<string>& classes, const string& new_name);
    
    // Export
    void ExportCOCO(const string& output_path);
    void ExportYOLO(const string& output_path);
    void ExportPascalVOC(const string& output_path);
    void ExportCyxWizNative(const string& output_path);
};
```

### 6.2 Auto-Labeling Integration
```cpp
class AutoLabeler {
    // Run ONNX model for pre-annotation
    vector<Annotation> GenerateAnnotations(
        const Dataset& images,
        const ONNXModel& model,
        float confidence_threshold
    );
    
    // Human-in-the-loop workflow
    void ReviewAutoAnnotations(
        const vector<Annotation>& auto_annotations,
        ReviewCallback on_accept_or_correct
    );
};
```

### 6.3 Annotation Quality Control
```
- Inter-annotator agreement (Fleiss' kappa, Cohen's kappa)
- Consistency checks (same object, different samples)
- Outlier detection (annotations significantly different from others)
- Review queue (flagged annotations for re-review)
```

---

## 🔹 LAYER 7 — Deployment & Training Integration

**Purpose:** Complete the loop from data to training

### 7.1 Export Wizard
```cpp
class ExportWizard {
    // Train/val/test split
    SplitConfig ConfigureSplits();
    
    // Format selection
    ExportFormat ChooseFormat();  // CSV, Parquet, NPZ, TFRecord, HDF5
    
    // Version tagging
    string AssignVersionTag();
    
    // Metadata attachment
    Metadata AttachMetadata();
    
    // Execute export
    ExportResult Export(const ExportConfig& config);
};
```

### 7.2 Node Editor Integration
```cpp
class DeploymentBridge {
    // Direct handoff to Node Editor
    void DeployToNodeEditor(
        const string& dataset_id,
        const string& version
    );
    
    // Implementation:
    void DeployToNodeEditor(const string& dataset_id, const string& version) {
        auto& registry = DataRegistry::Instance();
        auto dataset = registry.Get(dataset_id, version);
        
        auto& nodeEditor = ProjectManager::Instance().GetNodeEditor();
        nodeEditor.SetDataInputDataset(
            dataset->GetName(),
            dataset->GetShape(),
            dataset->GetDataType(),
            dataset->GetSplitMetadata()
        );
        
        PanelRegistry::Instance().Show("ModelBuilder");
    }
};
```

### 7.3 Remote Training (P2P)
```cpp
class RemoteTrainingDispatcher {
    // Submit job to P2P network
    JobID DispatchTrainingJob(
        const string& dataset_id,
        const string& model_config,
        const ComputeRequirements& requirements
    );
    
    // Upload dataset to CyxCloud
    string UploadDataset(const string& dataset_id);
    
    // Monitor training progress
    TrainingStatus GetJobStatus(const JobID& job_id);
    
    // Download trained model
    Model* DownloadModel(const JobID& job_id);
};
```

### 7.4 Pipeline Export
```cpp
class PipelineExporter {
    // Save pipeline as JSON
    void SavePipelineJSON(
        const Pipeline& pipeline,
        const string& output_path
    );
    
    // Generate Python script equivalent
    string GeneratePythonScript(const Pipeline& pipeline);
    
    // Export as reusable template
    void SaveAsTemplate(
        const Pipeline& pipeline,
        const string& template_name,
        const TemplateMetadata& metadata
    );
};
```

---

## 🔧 Cross-Cutting Concerns

### Plugin System Integration

All layers support plugins:

```cpp
// Layer 1 — Data Access
class IDataProvider {
    virtual bool CanHandle(const URI& source) = 0;
    virtual Dataset* Load(const URI& source) = 0;
};

// Layer 3 — Transformation
class INodeProvider {
    virtual vector<DSNode*> GetNodes() = 0;
};

// Layer 5 — Visualization
class IVisualizationProvider {
    virtual void Render(const Dataset& data, const json& config) = 0;
};

// Layer 6 — Annotation
class IAnnotationToolProvider {
    virtual AnnotationTool* GetTool() = 0;
};
```

### Error Handling Strategy

```cpp
class SafeExecute {
    // Crash isolation for plugin nodes
    template<typename Func>
    static bool SafeExecute(Func func) {
        try {
            func();
            return true;
        } catch (const std::exception& e) {
            CYXWIZ_LOG_ERROR("Plugin exception: {}", e.what());
            return false;
        } catch (...) {
            CYXWIZ_LOG_ERROR("Unknown plugin exception");
            return false;
        }
    }
};
```

### Parallel Execution

```cpp
class ThreadPoolExecutor {
    // Parallel batch processing
    void ExecuteBatch(
        const vector<Task>& tasks,
        int num_threads = std::thread::hardware_concurrency()
    );
    
    // GPU batch dispatch
    void ExecuteGPUBatch(
        const vector<GPUTask>& tasks,
        const ArrayFire& af_context
    );
};
```

---

## 📊 How This Architecture Serves ML Engineers

### For Computer Vision Engineers
```
Image Pipeline:
Load → Resize → Augment → Normalize → Split → Annotate → Export
                                              ↓
                                     Node Editor (CNN)
```

### For NLP Engineers
```
Text Pipeline:
Load → Clean → Tokenize → Embed → Pad Sequences → Split → Export
                                                      ↓
                                             Node Editor (Transformer)
```

### For Audio Engineers
```
Audio Pipeline:
Load → Resample → Denoise → MFCC → Normalize → Split → Export
                                                    ↓
                                           Node Editor (RNN/CNN)
```

### For Time-Series Engineers
```
Time-Series Pipeline:
Load → Window → Features → Scale → Temporal Split → Export
                                                 ↓
                                        Node Editor (LSTM/Temporal CNN)
```

---

## 🎯 Why This Architecture Wins

1. **Modality-First Design**: Every layer treats all modalities equally
2. **Version Control**: Every dataset is tracked, lineage is preserved
3. **ML-Optimized**: Every output is training-ready (correct shapes, dtypes, splits)
4. **Plugin-Extensible**: Every layer has plugin interfaces
5. **Zero Friction**: Direct handoff to Node Editor — no export/import dance
6. **Production-Ready**: Error handling, memory management, parallel execution
7. **KNIME-Proven**: The layer structure is battle-tested by 300,000+ KNIME users

---

## 🚀 Implementation Priority

### Phase 1 (Foundation)
- Layer 1 (Data Access)
- Layer 2 (Data Registry)
- Layer 3 (Basic tabular nodes)

### Phase 2 (Multi-Modal)
- Layer 3 (Image/Audio/Text/Video nodes)
- Layer 4 (Analysis & Profiling)

### Phase 3 (Visualization)
- Layer 5 (Visualization & Inspection)

### Phase 4 (Annotation)
- Layer 6 (Annotation & Labeling)

### Phase 5 (Deploy)
- Layer 7 (Training Integration)

---

## 📝 Summary

CyxWiz Data Studio is a **seven-layer ML data engineering platform** that:
- Mirrors KNIME's proven architecture
- Supports all ML modalities first-class
- Integrates directly with the Node Editor
- Provides complete version control and lineage tracking
- Extends via plugins at every layer
- Produces training-ready outputs with zero friction

This is the **solid ground** you need. Every future feature fits cleanly into one of these seven layers.
