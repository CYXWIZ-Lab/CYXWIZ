# CyxWiz Data Studio — Complete Layered Architecture
## Based on KNIME Analytics Platform Design Principles + CyxWiz ML Engineering Strengths

**Document Version:** 3.0  
**Date:** February 2026  
**Purpose:** Define the complete multi-layer system architecture for CyxWiz Data Studio that serves ML engineers across all domains and data modalities.

---

## Executive Summary

CyxWiz Data Studio is **not** a standalone application. It is a **unified orchestration layer** built directly into the CyxWiz Engine that consolidates scattered data preparation capabilities into a single, professional-grade workspace modeled on KNIME Analytics Platform's proven architecture.

**The Core Philosophy:**
> Don't rebuild what exists. Wrap, orchestrate, and extend your existing backend modules (dataset_analyzer.cpp, annotation_manager, tokenizer.cpp, audio_processing.cpp, time_series.cpp, OpenCV, FFmpeg, DuckDB) under a unified GUI and registry layer.

**The ML Engineering Promise:**
> Any ML engineer — whether building computer vision models, NLP systems, audio classifiers, time-series forecasters, or multi-modal architectures — can prepare their data in Data Studio and click one button to begin training in the Node Editor. Zero friction, zero file exports, zero context switching.

---

# PART 1 — THE SEVEN-LAYER ARCHITECTURE

CyxWiz Data Studio follows KNIME's proven separation-of-concerns architecture with seven distinct layers. Each layer has a clear responsibility and well-defined interfaces to adjacent layers.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  LAYER 7 — USER EXPERIENCE (ImGui GUI + Interaction Model)                 │
│  • Pipeline Canvas (imgui-node-editor)                                      │
│  • Asset Sidebar, Data Editor, Query Editor, Viz Tab, Analysis Tab          │
│  • Properties Panel, Script Editor, Phase Indicator                         │
└─────────────────────────────────────────────────────────────────────────────┘
                                    ↕
┌─────────────────────────────────────────────────────────────────────────────┐
│  LAYER 6 — WORKFLOW ORCHESTRATION (DataStudioManager)                      │
│  • Pipeline execution engine (DAG traversal + AsyncTaskManager)             │
│  • Node lifecycle management (configure → execute → finalize)               │
│  • Port type validation & data flow control                                 │
│  • Progress tracking, error handling, cancellation                          │
└─────────────────────────────────────────────────────────────────────────────┘
                                    ↕
┌─────────────────────────────────────────────────────────────────────────────┐
│  LAYER 5 — NODE ABSTRACTION (DSNode Interface + NodeRegistry)              │
│  • Typed input/output ports (Table, Image, Audio, Video, Text, TimeSeries) │
│  • Execute() contract: receives inputs → produces outputs                   │
│  • RenderConfig() for Properties Panel UI                                   │
│  • Plugin integration via INodeProvider (SafeExecute isolation)             │
└─────────────────────────────────────────────────────────────────────────────┘
                                    ↕
┌─────────────────────────────────────────────────────────────────────────────┐
│  LAYER 4 — DATA MODEL LAYER (Typed Dataset Abstractions)                   │
│  • BaseDataset → TabularDataset, ImageDataset, AudioDataset, etc.          │
│  • Apache Arrow RecordBatch for zero-copy tabular data transfer            │
│  • Modality-specific containers: ImageBatch, AudioBatch, etc.              │
│  • Schema inference, type coercion, validation                             │
└─────────────────────────────────────────────────────────────────────────────┘
                                    ↕
┌─────────────────────────────────────────────────────────────────────────────┐
│  LAYER 3 — PROCESSING BACKEND (Existing CyxWiz Modules + Open Source)      │
│  • DuckDB (SQL, tabular ops, schema detection)                              │
│  • OpenCV (image processing, video frame extraction)                        │
│  • FFmpeg (video decode, audio extraction)                                  │
│  • FFTW3 (audio spectral analysis)                                          │
│  • tokenizer.cpp, audio_processing.cpp, time_series.cpp (CyxWiz backend)   │
│  • ArrayFire (GPU acceleration for batch operations)                        │
└─────────────────────────────────────────────────────────────────────────────┘
                                    ↕
┌─────────────────────────────────────────────────────────────────────────────┐
│  LAYER 2 — STORAGE & REGISTRY (DataRegistry + PipelineRegistry)            │
│  • Dataset versioning: dataset_id → version → storage_path                  │
│  • LRU memory management for large datasets                                 │
│  • Pipeline serialization (JSON) with deterministic hashing                 │
│  • CyxCloud integration for remote storage                                  │
│  • Lineage tracking: which pipeline produced which dataset                  │
└─────────────────────────────────────────────────────────────────────────────┘
                                    ↕
┌─────────────────────────────────────────────────────────────────────────────┐
│  LAYER 1 — INFRASTRUCTURE (Engine Core Services)                           │
│  • AsyncTaskManager (background execution, thread pooling)                  │
│  • PluginManager (crash-isolated plugin loading via SafeExecute)           │
│  • PanelRegistry (docking system, panel lifecycle)                          │
│  • CyxCloud client (S3-compatible storage API)                              │
│  • Solana/blockchain integration (future: dataset provenance NFTs)          │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Layer 7 — User Experience (ImGui GUI)

**What KNIME Does:**
KNIME allows users to visually create data flows (or pipelines), selectively execute some or all analysis steps, and later inspect the results, models, using interactive widgets and views.

**What CyxWiz Implements:**

### A. Pipeline Canvas
- **Library:** imgui-node-editor (MIT, drop-in for ImNodes)
- **Visual Language:** KNIME-style node graph
  - Colored top border per category (blue=Input, amber=Tabular, purple=Text, teal=Analysis, green=Output)
  - Typed port dots (white=Table, orange=Image, cyan=Audio, yellow=TimeSeries)
  - Bezier curves with animated flow particles during execution
  - Execution state rings: grey=pending, spinning=running, green=done, red=error
- **Interaction:**
  - Right-click → node search popup with category tree (identical to KNIME repository)
  - Drag connections between typed ports (invalid connections rejected)
  - Box select, multi-node move, zoom/pan
  - Properties panel opens when node is clicked

### B. Seven-Tab Workspace
Each tab corresponds to a phase in the data workflow:

| Tab | Phase | Primary Function |
|-----|-------|------------------|
| **Pipeline** | Transform | Visual node graph editor |
| **Table** | Data Access + Explore | Interactive data viewer (wraps dataset_panel_interactive.cpp) |
| **Query** | Analyze | DuckDB SQL editor (ImGuiColorTextEdit + embedded execution) |
| **Analysis** | Analyze | Automated profiling (wraps dataset_analyzer.cpp) |
| **Visualize** | Visualize | ImPlot charts + media viewers (images, audio, video) |
| **Annotate** | Annotate | Wraps annotation_manager for supervised learning labeling |
| **Script** | All | Python scripting via pybind11 (pycyxwiz API) |

### C. Three Workspace Modes
Users switch mode via toolbar dropdown:

1. **Visual Mode:** Pipeline Canvas is primary. Properties panel shows node config. Script tab shows read-only auto-generated Python equivalent.
2. **Script Mode:** Python editor is primary. Users write `pycyxwiz` API code. Canvas reflects script in real-time.
3. **Hybrid Mode:** Side-by-side canvas + script. Changes in either are reflected in the other immediately.

### D. Asset Sidebar (220px left panel)
- **Datasets:** Tree view of all registered datasets with version tags
- **Pipelines:** Saved pipeline JSON files (shareable, re-executable)
- **Exports:** Output artifacts ready for download or CyxCloud upload
- **CyxCloud:** Remote bucket browser (drag parquet files directly onto canvas)

**Design Principle:** The GUI never implements business logic. It only renders state and dispatches actions to Layer 6.

---

## Layer 6 — Workflow Orchestration (DataStudioManager)

**What KNIME Does:**
The NodeFactory bundles all parts that make up a node. Thus, the factory provides creation methods for the NodeModel, NodeDialog, and NodeView. Furthermore, the factory will be registered via a KNIME extension point such that the node is discoverable by the framework and will be displayed in the node repository view of KNIME Analytics Platform.

**What CyxWiz Implements:**

### A. DataStudioManager — The Central Orchestrator

```cpp
// cyxwiz-engine/src/gui/panels/data_studio/data_studio_manager.h

class DataStudioManager {
public:
    static DataStudioManager& Instance();
    
    // Pipeline execution
    void ExecutePipeline(const PipelineID& id);
    void CancelExecution();
    void ExecuteNode(const NodeID& id);  // selective execution
    
    // Node lifecycle
    bool ValidatePipeline(const Pipeline& pipeline);  // port type checking
    ExecutionPlan CreateExecutionPlan(const Pipeline& pipeline);  // topological sort
    void ExecuteDAG(const ExecutionPlan& plan);  // async via AsyncTaskManager
    
    // State management
    PipelineState GetPipelineState(const PipelineID& id);
    NodeState GetNodeState(const NodeID& id);
    void SetNodeConfig(const NodeID& id, const nlohmann::json& config);
    
    // Integration hooks
    void DeployToNodeEditor(const DatasetHandle& dataset);
    void UploadToCyxCloud(const DatasetHandle& dataset, const std::string& bucket);
    
private:
    DataRegistry&       m_DataRegistry;
    PipelineRegistry&   m_PipelineRegistry;
    NodeRegistry&       m_NodeRegistry;
    AsyncTaskManager&   m_AsyncTaskManager;
};
```

### B. Pipeline Execution Model
The execution engine follows KNIME's approach:

1. **Configuration Phase:**
   - Call `node->Configure(inputSpecs)` on every node
   - Each node infers output schema from input schema
   - Validate downstream connections (port types must match)
   - If configuration fails, mark node as error and stop

2. **Execution Phase:**
   - Topological sort of DAG (nodes with no dependencies first)
   - For each node in order:
     - Fetch inputs from DataRegistry (previous node outputs)
     - Call `node->Execute(inputs, config, progressCallback)`
     - Store outputs in DataRegistry with temporary version tag
     - Update node state (running → done or error)
   - All executed in background thread via AsyncTaskManager

3. **Finalization Phase:**
   - Commit final dataset version to DataRegistry
   - Update pipeline execution history
   - Trigger Deploy phase UI if requested

**Key Design Decision:** Nodes never directly call other nodes. All communication is mediated through the DataRegistry. This enables:
- Partial re-execution (re-run from any node)
- Result caching (skip nodes if inputs unchanged)
- Parallel execution (if DAG has independent branches)

---

## Layer 5 — Node Abstraction (DSNode Interface)

**What KNIME Does:**
The NodeModel contains the actual implementation of what the node is supposed to do. Furthermore, it specifies the number of inputs and outputs of a node.

**What CyxWiz Implements:**

### A. DSNode Base Interface

```cpp
// cyxwiz-engine/src/gui/panels/data_studio/nodes/node_base.h

enum class PortType {
    Table,       // Arrow RecordBatch
    Image,       // ImageBatch (std::vector<cv::Mat>)
    Audio,       // AudioBatch (std::vector<AudioBuffer>)
    Video,       // VideoFrames
    Text,        // TextCorpus
    TimeSeries,  // TimeSeriesData
    Model,       // Trained model handle
    Any          // Type-erased (for generic passthrough nodes)
};

struct DSPort {
    std::string name;
    PortType    type;
    bool        optional = false;
};

struct DSResult {
    bool success;
    std::string errorMessage;
    std::unordered_map<std::string, std::any> outputs;  // port name → data
    
    static DSResult Success(std::unordered_map<std::string, std::any> outputs);
    static DSResult Error(const std::string& msg);
};

class DSNode {
public:
    virtual ~DSNode() = default;
    
    // Node metadata
    virtual const char* GetTypeID() const = 0;      // e.g. "FilterRows"
    virtual const char* GetCategory() const = 0;    // e.g. "Tabular"
    virtual const char* GetDisplayName() const = 0; // e.g. "Filter Rows"
    virtual const char* GetDescription() const = 0;
    
    // Port definitions
    virtual std::vector<DSPort> GetInputPorts() const = 0;
    virtual std::vector<DSPort> GetOutputPorts() const = 0;
    
    // Configuration phase (runs before execution)
    virtual bool Configure(
        const std::unordered_map<std::string, DataSchema>& inputSchemas,
        std::unordered_map<std::string, DataSchema>& outputSchemas) {
        return true;  // default: pass-through schema
    }
    
    // Execution phase (runs on background thread)
    virtual DSResult Execute(
        const std::unordered_map<std::string, std::any>& inputs,
        const nlohmann::json& config,
        ProgressCallback progress) = 0;
    
    // GUI rendering in Properties Panel (runs on main thread)
    virtual void RenderConfig(nlohmann::json& config) = 0;
    
    // Default configuration
    virtual nlohmann::json DefaultConfig() const { return {}; }
    
    // Validation
    virtual std::vector<std::string> Validate(const nlohmann::json& config) const {
        return {};  // no errors
    }
};
```

### B. Example Built-in Node: FilterRows

```cpp
// cyxwiz-engine/src/gui/panels/data_studio/nodes/tabular/filter_rows_node.cpp

class FilterRowsNode : public DSNode {
public:
    const char* GetTypeID()      const override { return "FilterRows"; }
    const char* GetCategory()    const override { return "Tabular"; }
    const char* GetDisplayName() const override { return "Filter Rows"; }
    const char* GetDescription() const override {
        return "Remove rows based on conditions: null rate, outliers (IQR/Z-score), "
               "hard bounds, or custom DuckDB WHERE clause.";
    }
    
    std::vector<DSPort> GetInputPorts() const override {
        return {{ "table", PortType::Table }};
    }
    std::vector<DSPort> GetOutputPorts() const override {
        return {{ "filtered", PortType::Table }};
    }
    
    DSResult Execute(
        const std::unordered_map<std::string, std::any>& inputs,
        const nlohmann::json& config,
        ProgressCallback progress) override
    {
        auto table     = std::any_cast<arrow::RecordBatch>(inputs.at("table"));
        auto method    = config.value("method", "IQR");
        auto column    = config.value("column", "");
        auto threshold = config.value("threshold", 1.5);
        
        // Dispatch to DuckDB for actual filtering
        auto& duckdb = DuckDB::Instance();
        std::string query;
        
        if (method == "IQR") {
            query = fmt::format(
                "SELECT * FROM input_table WHERE {} BETWEEN "
                "(SELECT percentile_cont(0.25) - {}*IQR FROM ...) AND "
                "(SELECT percentile_cont(0.75) + {}*IQR FROM ...)",
                column, threshold, threshold);
        } else if (method == "HardBounds") {
            auto min = config.value("min", -std::numeric_limits<double>::infinity());
            auto max = config.value("max",  std::numeric_limits<double>::infinity());
            query = fmt::format("SELECT * FROM input_table WHERE {} BETWEEN {} AND {}",
                                column, min, max);
        } else if (method == "CustomSQL") {
            query = config.value("sql_where", "TRUE");
        }
        
        auto result = duckdb.Execute(query, table);
        progress(1.0f);
        
        return DSResult::Success({{"filtered", result}});
    }
    
    void RenderConfig(nlohmann::json& config) override {
        // Rendered in Properties Panel when node is selected
        const char* methods[] = { "IQR", "Z-Score", "HardBounds", "CustomSQL" };
        int method_idx = /* ... */;
        if (ImGui::Combo("Method", &method_idx, methods, 4))
            config["method"] = methods[method_idx];
        
        if (config["method"] == "IQR" || config["method"] == "Z-Score") {
            float threshold = config.value("threshold", 1.5f);
            if (ImGui::SliderFloat("Threshold", &threshold, 0.5f, 5.0f))
                config["threshold"] = threshold;
        }
        
        if (config["method"] == "HardBounds") {
            float min = config.value("min", 0.0f);
            float max = config.value("max", 100.0f);
            ImGui::InputFloat("Min", &min);
            ImGui::InputFloat("Max", &max);
            config["min"] = min;
            config["max"] = max;
        }
        
        if (config["method"] == "CustomSQL") {
            static char sql_buf[512];
            strncpy(sql_buf, config.value("sql_where", "").c_str(), 511);
            if (ImGui::InputTextMultiline("WHERE clause", sql_buf, 512))
                config["sql_where"] = std::string(sql_buf);
        }
    }
    
    nlohmann::json DefaultConfig() const override {
        return {{"method", "IQR"}, {"threshold", 1.5}};
    }
};
```

### C. Plugin Node Integration

Plugin developers implement DSNode and register via INodeProvider:

```cpp
// External plugin: plugins/medical_imaging/clahe_node.cpp

class CLAHENode : public CyxWiz::DSNode {
    // ... implementation from earlier example
};

class MedicalNodeProvider : public INodeProvider {
public:
    std::vector<DSNode*> GetNodes() override {
        return { new CLAHENode() };
    }
};

// In plugin DLL entry point:
extern "C" PLUGIN_EXPORT void* QueryInterface(const char* interfaceId) {
    if (strcmp(interfaceId, "INodeProvider") == 0)
        return new MedicalNodeProvider();
    return nullptr;
}
```

**Safety:** All plugin node Execute() calls run inside SafeExecute (SEH/signal handling). A misbehaving plugin cannot crash the studio.

---

## Layer 4 — Data Model Layer (Typed Abstractions)

**What KNIME Does:**
KNIME's core-architecture allows processing of large data volumes that are only limited by the available hard disk space (not limited to the available RAM).

**What CyxWiz Implements:**

### A. BaseDataset Abstract Interface

```cpp
// cyxwiz-engine/src/core/base_dataset.h

enum class DataModality {
    Tabular, Image, Audio, Video, Text, TimeSeries, PointCloud, Graph
};

class BaseDataset {
public:
    virtual ~BaseDataset() = default;
    
    virtual DataModality GetModality() const = 0;
    virtual size_t       GetNumSamples() const = 0;
    virtual DataSchema   GetSchema() const = 0;
    
    // Batch loading (for large datasets that don't fit in RAM)
    virtual std::any LoadBatch(size_t start, size_t count) = 0;
    
    // Streaming interface (for real-time data like Kafka)
    virtual bool IsStreaming() const { return false; }
    virtual std::any GetNextBatch(size_t maxSamples) { return {}; }
    
    // Metadata
    virtual nlohmann::json GetMetadata() const = 0;
    virtual void SetMetadata(const nlohmann::json& meta) = 0;
    
    // Serialization
    virtual void SaveToFile(const std::string& path) const = 0;
    virtual void LoadFromFile(const std::string& path) = 0;
};
```

### B. Concrete Dataset Types

```cpp
// TabularDataset — wraps Apache Arrow RecordBatch
class TabularDataset : public BaseDataset {
private:
    std::shared_ptr<arrow::RecordBatch> m_Data;
    // For large datasets: DuckDB connection + lazy loading
    std::unique_ptr<duckdb::Connection> m_DuckDBConn;
    bool m_IsLazy = false;
    
public:
    std::any LoadBatch(size_t start, size_t count) override {
        if (m_IsLazy) {
            // Lazy load via DuckDB
            auto query = fmt::format("SELECT * FROM dataset LIMIT {} OFFSET {}", count, start);
            return m_DuckDBConn->Query(query)->Fetch();
        }
        return m_Data->Slice(start, count);
    }
};

// ImageDataset — wraps std::vector<cv::Mat> or lazy file paths
class ImageDataset : public BaseDataset {
private:
    std::vector<std::string> m_FilePaths;  // lazy loading
    std::vector<cv::Mat>     m_LoadedImages;  // memory cache (LRU managed)
    
public:
    std::any LoadBatch(size_t start, size_t count) override {
        std::vector<cv::Mat> batch;
        for (size_t i = start; i < start + count; ++i) {
            // Check DataRegistry cache first (LRU)
            if (auto cached = DataRegistry::Instance().GetCachedImage(m_FilePaths[i]))
                batch.push_back(cached);
            else
                batch.push_back(cv::imread(m_FilePaths[i]));
        }
        return batch;
    }
};

// AudioDataset — wraps audio file paths + libsndfile lazy loading
class AudioDataset : public BaseDataset {
private:
    std::vector<std::string> m_FilePaths;
    int m_SampleRate;
    int m_Channels;
    
public:
    std::any LoadBatch(size_t start, size_t count) override {
        std::vector<AudioBuffer> batch;
        for (size_t i = start; i < start + count; ++i) {
            SF_INFO info;
            SNDFILE* file = sf_open(m_FilePaths[i].c_str(), SFM_READ, &info);
            // ... read samples
            batch.push_back(AudioBuffer{samples, info.samplerate, info.channels});
            sf_close(file);
        }
        return batch;
    }
};

// TimeSeriesDataset — wraps time-indexed data (stock prices, sensor logs, etc.)
class TimeSeriesDataset : public BaseDataset {
private:
    std::shared_ptr<arrow::RecordBatch> m_Data;  // columns: timestamp, features...
    std::string m_TimestampColumn;
    
public:
    std::any LoadBatch(size_t start, size_t count) override {
        return m_Data->Slice(start, count);
    }
    
    // Time-series specific: windowing, resampling, lag features
    TimeSeriesDataset Window(int window_size, int stride);
    TimeSeriesDataset Resample(const std::string& freq);
};
```

### C. Zero-Copy Data Transfer via Apache Arrow

For tabular data, all inter-node communication uses Arrow RecordBatch:

- **Zero-copy:** When nodes run on the same thread, Arrow uses shared memory
- **Schema inference:** Arrow automatically detects column types
- **DuckDB interop:** DuckDB reads/writes Arrow batches natively
- **Columnar efficiency:** Analytics queries (GROUP BY, JOIN) are vectorized

```cpp
// Example: FilterRows node receives Arrow batch, passes to DuckDB, returns Arrow batch
auto filtered = duckdb.Execute("SELECT * FROM input WHERE price > 100000", inputBatch);
// No data copy — Arrow pointers passed through
```

---

## Layer 3 — Processing Backend (Existing Modules + Open Source)

**What KNIME Does:**
KNIME integrates various other open-source projects, e.g., machine learning algorithms from Weka, H2O, Keras, Spark, the R project and LIBSVM; plotly, JFreeChart, ImageJ, and the Chemistry Development Kit.

**What CyxWiz Implements:**

### A. Unified Backend Integration Table

| Data Type | Node Categories | CyxWiz Backend | Open-Source Library | Notes |
|-----------|-----------------|----------------|---------------------|-------|
| **Tabular** | FilterRows, SelectColumns, FillMissing, RemoveDuplicates, Join, Aggregate, Pivot | DuckDB C++ API | DuckDB (MIT) | All tabular operations dispatch to embedded DuckDB |
| **Text** | TextClean, Tokenize, Stem, Lemmatize, StopWords, NGrams, TFIDF, Embedding | tokenizer.cpp (CyxWiz) | RE2 (BSD-3), ICU4C (MIT), Snowball (BSD-3) | Reuse existing CyxWiz text pipeline |
| **Image** | Resize, Normalize, Augment, ColorSpace, Filter, Crop, Rotate | OpenCV integration | OpenCV 4.x (Apache-2.0) | Already integrated — just wrap in DSNode interface |
| **Audio** | Resample, Trim, Normalize, Denoise, MFCC, MelSpec, Spectrogram | audio_processing.cpp (CyxWiz) | libsndfile (LGPL-2.1), FFTW3 (GPL-2.0) | Reuse existing audio backend |
| **Video** | FrameExtract, Resize, SceneDetect, OpticalFlow | FFmpeg integration | FFmpeg libav* (LGPL-2.1) | Already available — wrap in DSNode |
| **Time-Series** | TSWindow, TSFeatures, TSLag, TSDiff, TSRolling, TSSplit | time_series.cpp (CyxWiz) | Intel TBB (Apache-2.0) | Existing backend for rolling window ops |
| **Feature Eng.** | StandardScale, MinMaxScale, OneHotEncode, LabelEncode, PCA | ArrayFire GPU kernels | ArrayFire (BSD-3) | GPU-accelerated normalization, encoding |

### B. Critical Design Principle: No Duplication

Every DSNode is a **thin wrapper** around an existing backend function. Example:

```cpp
// ImageResizeNode — wraps OpenCV cv::resize
DSResult ImageResizeNode::Execute(...) {
    auto images = std::any_cast<ImageBatch>(inputs.at("images"));
    int width   = config.value("width", 224);
    int height  = config.value("height", 224);
    
    ImageBatch resized;
    for (auto& img : images) {
        cv::Mat out;
        cv::resize(img, out, cv::Size(width, height));  // ← OpenCV does the work
        resized.push_back(out);
    }
    return DSResult::Success({{"resized", resized}});
}
```

**Why This Matters:**
- Writing a new node takes **hours, not days** — the algorithm already exists
- Bugs are fixed once in the backend, all nodes benefit
- GPU acceleration (via ArrayFire or cv::cuda) is added to the backend, all nodes accelerate automatically

---

## Layer 2 — Storage & Registry (DataRegistry + PipelineRegistry)

**What KNIME Does:**
A separate set of data has to be used for development. This does not need to be an exact reproduction of the productive data set. KNIME maintains separate development, testing, and production datasets.

**What CyxWiz Implements:**

### A. DataRegistry — Versioned Dataset Storage

```cpp
// cyxwiz-engine/src/core/data_registry.h

struct DatasetVersion {
    std::string id;              // e.g. "properties_data"
    int version;                 // e.g. 3
    std::string version_tag;     // e.g. "cleaned", "v1", "train_split"
    DataModality modality;
    std::shared_ptr<BaseDataset> data;
    size_t memory_size;          // bytes
    std::time_t created;
    nlohmann::json metadata;
    std::string lineage;         // pipeline_id that created this version
};

class DataRegistry {
public:
    static DataRegistry& Instance();
    
    // Register a dataset (creates version 1)
    void Register(const std::string& id, std::shared_ptr<BaseDataset> data, 
                  const std::string& tag = "v1");
    
    // Create a new version (immutable versioning)
    void CreateVersion(const std::string& id, std::shared_ptr<BaseDataset> data,
                       const std::string& tag, const std::string& pipeline_id);
    
    // Retrieve by id + version
    std::shared_ptr<BaseDataset> Get(const std::string& id, int version = -1);  // -1 = latest
    std::shared_ptr<BaseDataset> Get(const std::string& id, const std::string& tag);
    
    // List all versions of a dataset
    std::vector<DatasetVersion> GetVersions(const std::string& id);
    
    // Memory management (LRU eviction)
    void SetMemoryBudget(size_t bytes);
    size_t GetMemoryUsage() const;
    void EvictLRU();  // called automatically when budget exceeded
    
    // CyxCloud sync
    void UploadToCyxCloud(const std::string& id, int version, const std::string& bucket);
    void DownloadFromCyxCloud(const std::string& cloud_uri);
    
private:
    std::unordered_map<std::string, std::vector<DatasetVersion>> m_Datasets;
    size_t m_MemoryBudget = 16ULL * 1024 * 1024 * 1024;  // 16 GB default
    std::list<std::pair<std::string, int>> m_LRUList;  // (id, version)
};
```

**Key Features:**
- **Immutable Versioning:** Once created, a dataset version never changes. New transformations create new versions.
- **Lineage Tracking:** Every version records which pipeline created it.
- **LRU Memory Management:** When memory budget is exceeded, least-recently-used versions are evicted (but not deleted — reloaded from disk if needed).
- **Tag-Based Access:** Users refer to datasets as `properties_data:cleaned` or `sensor_logs:v3` instead of raw file paths.

### B. PipelineRegistry — Pipeline Serialization

```cpp
// cyxwiz-engine/src/core/pipeline_registry.h

struct Pipeline {
    std::string id;
    std::string name;
    std::vector<NodeInstance> nodes;  // node instances with configs
    std::vector<Edge> edges;          // connections between nodes
    std::string hash;                 // deterministic SHA256 of pipeline JSON
    std::time_t created;
    std::time_t last_modified;
    nlohmann::json metadata;
};

class PipelineRegistry {
public:
    static PipelineRegistry& Instance();
    
    void Save(const Pipeline& pipeline, const std::string& filepath);
    Pipeline Load(const std::string& filepath);
    
    std::string ComputeHash(const Pipeline& pipeline);  // for deterministic execution
    
    // Execution history
    void RecordExecution(const std::string& pipeline_id, 
                         const std::string& input_dataset,
                         const std::string& output_dataset,
                         bool success,
                         const std::string& error_msg = "");
    
    std::vector<ExecutionRecord> GetHistory(const std::string& pipeline_id);
};
```

**Pipeline JSON Format:**
```json
{
  "id": "real_estate_cleaning",
  "name": "Property Price Data Cleaning Pipeline",
  "version": "1.0",
  "nodes": [
    {
      "id": "node_1",
      "type": "FileInput",
      "config": {"path": "/data/properties_raw.csv"}
    },
    {
      "id": "node_2",
      "type": "RemoveDuplicates",
      "config": {"columns": ["property_id"], "keep": "first"}
    },
    {
      "id": "node_3",
      "type": "FilterRows",
      "config": {"method": "IQR", "column": "price", "threshold": 1.5}
    }
  ],
  "edges": [
    {"from": "node_1", "from_port": "output", "to": "node_2", "to_port": "table"},
    {"from": "node_2", "from_port": "filtered", "to": "node_3", "to_port": "table"}
  ],
  "hash": "a3f8d92c...",
  "metadata": {
    "created_by": "user@cyxwiz.ai",
    "description": "Cleans raw property data for price prediction model"
  }
}
```

**Blockchain Integration (Future):**
The pipeline hash can be registered on Solana as a verifiable provenance record. When a model is trained on CyxWiz's decentralized compute network, the training job includes the pipeline hash — miners verify the data was prepared with the exact same transformations.

---

## Layer 1 — Infrastructure (Engine Core Services)

**What KNIME Does:**
As part of a highly available architecture, KNIME Server 4.18 allows you to distribute execution of workflows over several Executors that can sit on separate hardware resources.

**What CyxWiz Implements:**

### A. AsyncTaskManager — Background Execution

All node execution happens on background threads. The main thread only renders UI.

```cpp
// cyxwiz-engine/src/core/async_task_manager.h

class AsyncTaskManager {
public:
    static AsyncTaskManager& Instance();
    
    TaskID SubmitTask(std::function<void()> task, const std::string& description);
    void CancelTask(TaskID id);
    
    TaskStatus GetStatus(TaskID id);
    float GetProgress(TaskID id);
    std::string GetErrorMessage(TaskID id);
    
    void WaitForTask(TaskID id);  // blocking
    void WaitForAll();
    
private:
    std::unique_ptr<ThreadPool> m_ThreadPool;  // 12 threads default
    std::unordered_map<TaskID, TaskInfo> m_Tasks;
};
```

**Integration with Nodes:**
```cpp
// In DataStudioManager::ExecuteNode()
auto taskID = AsyncTaskManager::Instance().SubmitTask([=]() {
    auto result = node->Execute(inputs, config, [&](float p) {
        AsyncTaskManager::Instance().UpdateProgress(taskID, p);
    });
    if (!result.success) {
        node->state = NodeState::Error;
        node->errorMsg = result.errorMessage;
    } else {
        node->state = NodeState::Done;
        DataRegistry::Instance().CreateVersion(outputDatasetID, result.outputs["output"], "v1", pipelineID);
    }
}, fmt::format("Executing {}", node->GetDisplayName()));
```

### B. PluginManager — Crash-Isolated Loading

```cpp
// cyxwiz-engine/src/core/plugin_manager.h

class PluginManager {
public:
    void LoadPlugin(const std::string& dllPath);
    std::vector<DSNode*> GetPluginNodes();
    std::vector<IDataProvider*> GetDataProviders();
    
    // SafeExecute wrapper
    template<typename Func>
    bool SafeExecute(Func&& func, std::string& errorMsg);
};

// Usage in node execution:
std::string error;
bool success = PluginManager::Instance().SafeExecute([&]() {
    result = pluginNode->Execute(inputs, config, progress);
}, error);

if (!success) {
    CYXWIZ_LOG_ERROR("Plugin node '{}' crashed: {}", pluginNode->GetTypeID(), error);
    node->state = NodeState::Error;
    node->errorMsg = "Plugin node caused a fault and was terminated";
}
```

**Platform-Specific Isolation:**
- **Windows:** Structured Exception Handling (SEH) catches access violations, divide-by-zero, stack overflow
- **Linux/macOS:** Signal handlers catch SIGSEGV, SIGFPE, SIGILL

### C. CyxCloud Integration

```cpp
// cyxwiz-engine/src/cloud/cyxcloud_client.h

class CyxCloudClient {
public:
    static CyxCloudClient& Instance();
    
    // Dataset operations
    void UploadDataset(const std::string& bucket, 
                       const std::string& key, 
                       std::shared_ptr<BaseDataset> dataset,
                       ProgressCallback progress);
    
    std::shared_ptr<BaseDataset> DownloadDataset(const std::string& bucket,
                                                   const std::string& key,
                                                   ProgressCallback progress);
    
    std::vector<std::string> ListBuckets();
    std::vector<std::string> ListKeys(const std::string& bucket, const std::string& prefix = "");
    
    // Streaming (for Parquet chunk loading)
    std::unique_ptr<DataStream> StreamDataset(const std::string& uri);
};
```

**CloudImport Node Integration:**
```cpp
// CloudImport node — streaming Parquet from CyxCloud
DSResult CloudImportNode::Execute(...) {
    auto bucket = config.value("bucket", "");
    auto key    = config.value("key", "");
    
    auto stream = CyxCloudClient::Instance().StreamDataset(
        fmt::format("s3://{}/{}", bucket, key));
    
    // DuckDB can read Parquet streams directly
    auto table = duckdb.ReadParquetStream(stream);
    return DSResult::Success({{"table", table}});
}
```

---

# PART 2 — DOMAIN-SPECIFIC WORKFLOWS

Now let's see how this architecture serves ML engineers across **seven major domains**. Each domain has unique data types, preprocessing needs, and visualization requirements — but they all use the same seven-layer architecture.

---

## Domain 1 — Computer Vision

**Typical ML Tasks:** Object detection, image classification, semantic segmentation, pose estimation, OCR

**Data Types:** Images (JPEG/PNG/TIFF), videos (MP4/AVI), annotation files (COCO JSON, YOLO txt, Pascal VOC XML)

**Pipeline Example: Object Detection Dataset Prep**

```
Load Images (10k JPEG) 
  → Filter Corrupted (check if cv::imread succeeds)
  → Resize (640×640)
  → Augment 5× (flip, rotate, brightness, contrast, noise)
  → Split Train/Val/Test (70/15/15 stratified by class)
  → Load COCO Annotations
  → Validate Annotations (check bbox bounds, missing labels)
  → Export to Node Editor
```

**Nodes Used:**
- FileInput → ImageDataset
- FilterRows (checks image validity via OpenCV)
- ImageResize
- ImageAugment (13 presets: HorizontalFlip, VerticalFlip, Rotate90, RandomRotate, RandomCrop, ColorJitter, GaussianBlur, GaussianNoise, Cutout, Mosaic, MixUp, CutMix, GridMask)
- TrainValTestSplit (stratified by class distribution)
- LoadAnnotations (COCO/YOLO/VOC parser)
- ValidateAnnotations (checks bbox coordinates, label consistency)
- ExportTraining → populates DataInput node with dataset handle

**Visualization Tab:**
- Image gallery (thumbnail grid, configurable size)
- Click image → full-screen with annotation overlay (bboxes, masks)
- Augmentation preview: side-by-side original vs augmented
- Class distribution bar chart

**Analysis Tab:**
- Image quality metrics: blur score (Laplacian variance), brightness histogram, contrast, noise estimate
- Duplicate detection (pHash/aHash/dHash)
- Class balance report with imbalance ratio
- Recommendation: "Class imbalance detected (8:1 ratio). Consider adding SMOTE node or class-weighted loss in training."

---

## Domain 2 — Natural Language Processing (NLP)

**Typical ML Tasks:** Text classification, sentiment analysis, named entity recognition, machine translation, question answering

**Data Types:** Text files (TXT, CSV, JSON), tokenized corpora, word embeddings

**Pipeline Example: Sentiment Analysis Dataset Prep**

```
Load CSV (100k tweets)
  → SelectColumns (text, label)
  → FilterRows (remove rows where text is null or len < 10)
  → TextClean (lowercase, remove URLs, remove HTML, strip punctuation, normalize unicode)
  → Tokenize (method: Word, language: English)
  → StopWords (remove: NLTK English stopwords)
  → Stem (method: Porter)
  → TFIDF (max_features: 10000, ngram_range: (1,2))
  → Split Train/Val/Test (80/10/10 stratified by label)
  → Export to Node Editor
```

**Nodes Used:**
- FileInput → TabularDataset (CSV)
- SelectColumns
- FilterRows (checks text length, null rate)
- TextClean (wraps tokenizer.cpp + RE2 regex)
- Tokenize (Word/Whitespace/Char/Sentence, multiple languages via ICU)
- StopWords (NLTK, spaCy, or custom list)
- Stem (Porter, Snowball, Lancaster via Snowball C library)
- Lemmatize (WordNet via NLTK Python bridge)
- NGrams (n=2 for bigrams, n=3 for trigrams)
- TFIDF (sparse matrix output, compatible with sklearn)
- Embedding (FastText pre-trained vectors, 300-dim)
- TrainValTestSplit (stratified by label)
- ExportTraining → tensor shape [N, 10000] for TFIDF, [N, L, 300] for embeddings

**Visualization Tab:**
- Word cloud of top 100 tokens
- Token frequency histogram
- Label distribution pie chart
- Sample text viewer (click row → see cleaned text vs original)

**Analysis Tab:**
- Vocabulary size, average text length (tokens), unique tokens
- Label balance report
- Out-of-vocabulary (OOV) rate if using pre-trained embeddings
- Language detection (via langdetect Python library)

---

## Domain 3 — Audio Processing & Speech

**Typical ML Tasks:** Speech recognition, speaker identification, audio event detection, music genre classification

**Data Types:** Audio files (WAV, MP3, FLAC), spectrograms, MFCC features

**Pipeline Example: Speech Command Recognition**

```
Load Audio Folder (5000 WAV files)
  → AudioResample (target: 16 kHz)
  → AudioTrim (remove silence: threshold -40 dB)
  → AudioNormalize (peak normalization)
  → MFCC Extract (n_mfcc: 13, n_fft: 2048, hop_length: 512)
  → Pad/Truncate (fixed length: 100 frames)
  → Split Train/Val/Test (70/15/15 stratified by label)
  → Export to Node Editor
```

**Nodes Used:**
- FileInput → AudioDataset
- AudioResample (wraps libsamplerate or FFmpeg)
- AudioTrim (VAD via energy threshold or WebRTC VAD)
- AudioNormalize (peak, RMS, or LUFS normalization)
- AudioDenoise (spectral subtraction or Wiener filter)
- AudioAugment (time stretch, pitch shift, add noise, time mask, frequency mask)
- MFCC (wraps audio_processing.cpp + FFTW3)
- MelSpectrogram (wraps audio_processing.cpp)
- Spectrogram (short-time Fourier transform)
- PadTruncate (zero-pad or truncate to fixed length)
- TrainValTestSplit
- ExportTraining → tensor shape [N, 100, 13] for MFCC

**Visualization Tab:**
- Waveform viewer (Wavesurfer.js-style)
- Spectrogram overlay (STFT with colormap)
- MFCC coefficient heatmap
- Playback controls (via miniaudio or SDL_mixer)

**Analysis Tab:**
- Audio quality: SNR estimate, clipping detection, silence ratio
- Sample rate distribution (if dataset has mixed rates)
- Duration histogram (seconds)
- Label balance

---

## Domain 4 — Time-Series Forecasting

**Typical ML Tasks:** Stock price prediction, sensor anomaly detection, energy demand forecasting, weather prediction

**Data Types:** CSV/Parquet with timestamp column, sensor logs, financial data

**Pipeline Example: Multivariate Sensor Anomaly Detection**

```
Load Parquet from CyxCloud (2.6M rows, 500 machines, 6 sensors)
  → FillMissing (method: linear interpolation)
  → FilterRows (remove calibration windows)
  → TSWindow (window_size: 60, stride: 30, group_by: machine_id)
  → TSFeatures (operations: [mean, std, min, max], rms_columns: [vibration])
  → StandardScale (all features)
  → Split Train/Val (80/20 stratified by machine_id)
  → Export to Node Editor
```

**Nodes Used:**
- CloudImport → TimeSeriesDataset (DuckDB Parquet streaming)
- FillMissing (forward-fill, backward-fill, linear interpolation, spline)
- FilterRows
- TSWindow (wraps time_series.cpp — rolling window with group-by)
- TSFeatures (rolling mean, std, min, max, median, skew, kurtosis, RMS, rate-of-change)
- TSLag (create lagged features: t-1, t-2, t-7 for weekly patterns)
- TSDiff (first-order or second-order differencing for stationarity)
- TSRolling (exponential moving average, rolling sum)
- TSSplit (time-based split: train before date X, val/test after date X)
- StandardScale
- ExportTraining → two tensors: sequences [N, 60, 6] and features [N, 34]

**Visualization Tab:**
- Line plot of all sensors over time (ImPlot with zoom/pan)
- Anomaly windows highlighted in red
- Distribution comparison: normal vs anomalous windows
- Correlation heatmap of sensor readings

**Analysis Tab:**
- Stationarity test (Augmented Dickey-Fuller)
- Autocorrelation function (ACF) and partial ACF (PACF) plots
- Anomaly rate (% of windows with 3-sigma exceedance)
- Normal operating range per sensor (mean ± 3 std)

---

## Domain 5 — Video Understanding

**Typical ML Tasks:** Action recognition, video classification, temporal segmentation, video captioning

**Data Types:** Video files (MP4, AVI, MOV), extracted frames, optical flow

**Pipeline Example: Action Recognition Dataset Prep**

```
Load Video Folder (500 MP4 files, 30 fps, ~5 seconds each)
  → VideoFrameExtract (fps: 10, every 3rd frame)
  → VideoResize (224×224)
  → VideoNormalize (ImageNet mean/std)
  → VideoSceneDetect (threshold: 30.0)
  → Split Train/Val/Test (70/15/15 stratified by label)
  → Export to Node Editor
```

**Nodes Used:**
- FileInput → VideoDataset
- VideoFrameExtract (wraps FFmpeg libavcodec, configurable fps)
- VideoResize (wraps FFmpeg filters)
- VideoNormalize (apply ImageNet normalization per frame)
- VideoSceneDetect (PySceneDetect algorithm: threshold-based or content-aware)
- VideoOpticalFlow (Farneback dense optical flow via OpenCV)
- VideoAugment (temporal crop, frame drop, playback speed)
- TrainValTestSplit
- ExportTraining → tensor shape [N, T, 3, 224, 224] where T is number of frames

**Visualization Tab:**
- Frame strip viewer (thumbnail grid of frames)
- Scene boundary markers overlaid on timeline
- Optical flow visualization (color-coded motion vectors)
- Video player with frame-level navigation

**Analysis Tab:**
- Average video duration, frame count, resolution
- Scene count distribution
- Motion intensity histogram (optical flow magnitude)
- Label balance

---

## Domain 6 — Tabular Data & Structured ML

**Typical ML Tasks:** Classification, regression, clustering, anomaly detection on structured data (customer churn, fraud detection, credit scoring)

**Data Types:** CSV, Parquet, database tables, Excel files

**Pipeline Example: Customer Churn Prediction**

```
Load CSV (100k customers, 50 features)
  → SelectColumns (drop: customer_id, timestamp)
  → FilterRows (remove: churn_date is null AND status == 'inactive')
  → FillMissing (numeric: median, categorical: mode)
  → TypeCast (convert date strings to ordinals)
  → OneHotEncode (columns: [region, subscription_tier])
  → StandardScale (numeric columns)
  → PCA (n_components: 20, for visualization)
  → FeatureSelect (method: mutual_info, top_k: 30)
  → Split Train/Val/Test (70/15/15 stratified by churn_label)
  → Export to Node Editor
```

**Nodes Used:**
- FileInput / DatabaseQuery → TabularDataset
- SelectColumns
- FilterRows (SQL WHERE clause or Python lambda)
- FillMissing (median, mean, mode, KNN imputation, forward-fill)
- RemoveDuplicates
- TypeCast (string→int, string→datetime, etc.)
- OneHotEncode (creates new columns, drops original)
- LabelEncode (ordinal encoding for ordinal categorical)
- StandardScale (z-score normalization)
- MinMaxScale (0-1 normalization)
- RobustScale (median + IQR, robust to outliers)
- PCA (dimensionality reduction)
- FeatureSelect (mutual information, chi-square, ANOVA F-test, L1 regularization)
- JoinDatasets (SQL-style join on key columns)
- Aggregate (GROUP BY operations)
- Pivot (reshape wide ↔ long)
- TrainValTestSplit
- ExportTraining → tensor shape [N, 30] after feature selection

**Visualization Tab:**
- Correlation heatmap (ImPlot)
- Feature distribution histograms (grid layout)
- PCA scatter plot (2D or 3D, colored by label)
- Pair plot for top 5 features

**Analysis Tab:**
- Descriptive statistics per column
- Null rate, cardinality, unique count
- Outlier detection (IQR, Z-score, Isolation Forest)
- Class balance report
- Feature importance (if using tree-based models in Analysis phase)

---

## Domain 7 — Multi-Modal Learning

**Typical ML Tasks:** Vision-language models (CLIP, BLIP), audio-visual speech recognition, video captioning, medical imaging with clinical notes

**Data Types:** Combinations of images + text, audio + video, point clouds + images

**Pipeline Example: Image Captioning Dataset Prep**

```
Load Image Folder + Captions CSV (10k images with 5 captions each)
  → FilterRows (remove: caption length < 10 or image file missing)
  → ImageResize (224×224)
  → ImageNormalize (ImageNet mean/std)
  → TextClean (lowercase, remove punctuation)
  → Tokenize (method: Word)
  → PadTruncate (max_length: 50 tokens)
  → Split Train/Val/Test (70/15/15)
  → Export to Node Editor (two tensors)
```

**Nodes Used:**
- FileInput (image folder + CSV join on filename)
- JoinDatasets (merge images with captions on filename key)
- ImageResize, ImageNormalize
- TextClean, Tokenize, PadTruncate
- TrainValTestSplit
- ExportTraining → two DataInput nodes populated:
  - Images: [N, 3, 224, 224]
  - Captions: [N, 50] (tokenized + padded)

**Visualization Tab:**
- Image gallery with caption overlay
- Caption length distribution histogram
- Word cloud of caption tokens

**Analysis Tab:**
- Image quality metrics
- Text statistics (vocab size, avg caption length)
- Modality alignment check: ensure every image has at least one caption

---

# PART 3 — DEPLOYMENT & TRAINING INTEGRATION

The Deploy phase is where CyxWiz Data Studio becomes fundamentally different from KNIME and every other data tool.

---

## The Deploy Workflow

### Step 1 — User Completes Pipeline

Pipeline has executed successfully. Final dataset is registered in DataRegistry with version tag (e.g., `properties_cleaned:v1`).

### Step 2 — User Opens Deploy Tab

The Export Wizard shows:

- **Dataset Summary:** Row count, column count, memory size, data type distribution
- **Split Configuration:**
  - Train/Val/Test ratios (default 70/15/15)
  - Stratification column (for classification)
  - Random seed (for reproducibility)
- **Export Options:**
  - **Option A:** Export to File (CSV, Parquet, NPZ, HDF5, TFRecord)
  - **Option B:** Upload to CyxCloud (versioned, metadata-tagged)
  - **Option C:** Deploy to Node Editor (direct training handoff)
  - **Option D:** Deploy to Remote Training (P2P compute network)

### Step 3 — User Clicks "Deploy to Node Editor"

```cpp
// In ds_export_wizard.cpp
void DSExportWizard::OnDeployToNodeEditor() {
    // 1. Get final dataset from DataRegistry
    auto& registry = DataRegistry::Instance();
    auto dataset = registry.Get(m_ActiveDataset);
    
    // 2. Create DatasetHandle with metadata
    DatasetHandle handle;
    handle.name = m_ExportConfig.datasetName;
    handle.shape = dataset->GetSchema().shape;
    handle.dtype = dataset->GetSchema().dtype;
    handle.splits = {
        {"train", dataset->GetSplit("train")},
        {"val",   dataset->GetSplit("val")},
        {"test",  dataset->GetSplit("test")}
    };
    
    // 3. Pass handle to Model Builder's DataInput node
    auto& nodeEditor = ProjectManager::Instance().GetNodeEditor();
    nodeEditor.SetDataInputDataset(handle);
    
    // 4. Navigate to Model Builder panel
    PanelRegistry::Instance().Show("ModelBuilder");
    
    // 5. Highlight DataInput node (visual confirmation)
    nodeEditor.HighlightNode("DataInput");
    
    CYXWIZ_LOG_INFO("Deployed '{}' to Node Editor — shape {}, {} samples",
                    handle.name, handle.shape, dataset->GetNumSamples());
}
```

### Step 4 — Node Editor Receives Dataset

The DataInput node in the Model Builder is now pre-populated:

```
┌──────────────────────────────────────────┐
│  📂 DataInput                             │
│  ────────────────────────────────────────│
│  Dataset: properties_cleaned:v1          │
│  Shape:   [74908, 31]                    │
│  Dtype:   Float32                        │
│  ────────────────────────────────────────│
│  Splits:  Train   60,774 (81.1%)         │
│           Val      7,596 (10.1%)         │
│           Test     7,538  (8.8%)         │
└──────────────────────────────────────────┘
        ↓ (user connects to next layer)
┌──────────────────────────────────────────┐
│  🧠 Linear Layer                          │
│  ────────────────────────────────────────│
│  Input:  31 features                     │
│  Output: 128 neurons                     │
│  Activation: ReLU                        │
└──────────────────────────────────────────┘
```

The user immediately starts building the model architecture. **No file export, no manual loading, no Python script, no context switching.**

---

## Remote Training via P2P Compute Network

For large datasets or GPU-intensive training, users can deploy to a reserved CyxWiz Server Node instead of training locally.

### Step 1 — Reserve Compute Node

User visits CyxWiz Marketplace (or CLI) and reserves a Server Node:
- GPU specs: NVIDIA A100 80GB
- Duration: 4 hours
- Cost: 25 CYXWIZ tokens (paid via Solana)
- Reservation ID: `srv_abc123`

### Step 2 — Deploy to Remote Node

In the Deploy tab, user selects "Deploy to Remote Training" and picks `srv_abc123` from the dropdown.

```cpp
// In ds_export_wizard.cpp
void DSExportWizard::OnDeployToRemote(const std::string& nodeID) {
    // 1. Upload dataset to CyxCloud (if not already there)
    auto& cloud = CyxCloudClient::Instance();
    std::string cloud_uri = cloud.UploadDataset(
        "training-data",  // bucket
        fmt::format("{}/{}.parquet", m_ActiveDataset, m_Version),
        m_Dataset,
        [&](float p) { UpdateProgress("Uploading to CyxCloud", p); }
    );
    
    // 2. Package training job
    TrainingJob job;
    job.pipeline_hash = m_PipelineRegistry.ComputeHash(m_Pipeline);
    job.dataset_uri = cloud_uri;
    job.node_editor_json = m_NodeEditor.SerializeToJSON();
    job.hyperparameters = m_TrainingConfig;
    
    // 3. Submit to P2P network
    auto& p2p = P2PClient::Instance();
    JobID jobID = p2p.SubmitJob(nodeID, job);
    
    // 4. Open Training Monitor panel
    PanelRegistry::Instance().Show("TrainingMonitor");
    TrainingMonitor::Instance().AttachToJob(jobID);
    
    CYXWIZ_LOG_INFO("Submitted training job {} to node {}", jobID, nodeID);
}
```

### Step 3 — Server Node Executes

The remote Server Node:
1. Downloads dataset from CyxCloud
2. Verifies pipeline hash matches (data provenance)
3. Loads Node Editor architecture
4. Begins training
5. Streams metrics back to user's Training Monitor panel (loss, accuracy, GPU util)
6. On completion, uploads trained model checkpoint to CyxCloud
7. Notifies user (desktop notification + email)

### Step 4 — User Downloads Trained Model

Training Monitor shows "✓ Complete — 96.2% val accuracy". User clicks "Download Model" and the checkpoint appears in their local project directory.

---

# PART 4 — PLUGIN ECOSYSTEM & EXTENSIBILITY

The seven-layer architecture is designed for extensibility at every level.

---

## Extension Point 1 — Custom Data Loaders (IDataProvider)

**Use Case:** Load proprietary data formats (DICOM medical images, LiDAR point clouds, genomics FASTQ files).

```cpp
// External plugin: plugins/medical_imaging/dicom_provider.cpp

class DICOMDataProvider : public IDataProvider {
public:
    const char* GetFormatName() const override { return "DICOM Medical Images"; }
    std::vector<const char*> GetFileExtensions() const override {
        return {".dcm", ".dicom"};
    }
    
    bool CanLoad(const std::string& filepath) override {
        // Check DICOM magic bytes
        std::ifstream f(filepath, std::ios::binary);
        char buf[4];
        f.read(buf, 4);
        return (memcmp(buf, "DICM", 4) == 0);
    }
    
    std::shared_ptr<BaseDataset> Load(const std::string& filepath) override {
        // Use DCMTK library to parse DICOM
        DcmFileFormat dcmFile;
        dcmFile.loadFile(filepath.c_str());
        
        // Extract pixel data, patient metadata, etc.
        auto pixelData = /* ... */;
        auto metadata = /* ... */;
        
        return std::make_shared<ImageDataset>(pixelData, metadata);
    }
};
```

After loading this plugin, DICOM files appear in the FileInput node's supported formats dropdown automatically.

---

## Extension Point 2 — Custom Nodes (INodeProvider)

**Use Case:** Domain-specific transformations (financial indicators for time-series, medical image preprocessing, custom augmentations).

Example: RSI (Relative Strength Index) node for financial time-series:

```cpp
// External plugin: plugins/finance/rsi_node.cpp

class RSINode : public DSNode {
public:
    const char* GetTypeID()      const override { return "RSI"; }
    const char* GetCategory()    const override { return "Finance/Technical Indicators"; }
    const char* GetDisplayName() const override { return "Relative Strength Index"; }
    
    std::vector<DSPort> GetInputPorts() const override {
        return {{ "timeseries", PortType::TimeSeries }};
    }
    std::vector<DSPort> GetOutputPorts() const override {
        return {{ "rsi", PortType::TimeSeries }};
    }
    
    DSResult Execute(
        const std::unordered_map<std::string, std::any>& inputs,
        const nlohmann::json& config,
        ProgressCallback progress) override
    {
        auto ts = std::any_cast<TimeSeriesDataset>(inputs.at("timeseries"));
        int period = config.value("period", 14);
        
        // Calculate RSI
        // RS = Average Gain / Average Loss over period
        // RSI = 100 - (100 / (1 + RS))
        auto close_prices = ts.GetColumn("close");
        std::vector<double> rsi_values;
        
        for (size_t i = period; i < close_prices.size(); ++i) {
            double avg_gain = 0, avg_loss = 0;
            for (size_t j = i - period; j < i; ++j) {
                double change = close_prices[j+1] - close_prices[j];
                if (change > 0) avg_gain += change;
                else avg_loss += -change;
            }
            avg_gain /= period;
            avg_loss /= period;
            double rs = (avg_loss == 0) ? 100 : avg_gain / avg_loss;
            double rsi = 100 - (100 / (1 + rs));
            rsi_values.push_back(rsi);
            progress(float(i) / close_prices.size());
        }
        
        // Create new time-series with RSI column
        auto result = ts.Clone();
        result.AddColumn("rsi", rsi_values);
        return DSResult::Success({{"rsi", result}});
    }
    
    void RenderConfig(nlohmann::json& config) override {
        int period = config.value("period", 14);
        if (ImGui::SliderInt("Period", &period, 5, 50))
            config["period"] = period;
        ImGui::TextWrapped("RSI > 70: overbought. RSI < 30: oversold.");
    }
    
    nlohmann::json DefaultConfig() const override {
        return {{"period", 14}};
    }
};
```

This node appears in the canvas context menu under `Finance / Technical Indicators / Relative Strength Index`.

---

## Extension Point 3 — Custom Analysis Metrics (IAnalyticsProvider)

**Use Case:** Domain-specific data quality checks (HIPAA compliance for medical data, GDPR checks for EU customer data, custom outlier detection algorithms).

```cpp
// External plugin: plugins/compliance/gdpr_checker.cpp

class GDPRAnalyticsProvider : public IAnalyticsProvider {
public:
    const char* GetName() const override { return "GDPR Compliance Checker"; }
    
    AnalysisResult Analyze(std::shared_ptr<BaseDataset> dataset) override {
        AnalysisResult result;
        
        // Check for PII columns (email, phone, IP address, etc.)
        auto schema = dataset->GetSchema();
        for (auto& col : schema.columns) {
            if (ContainsPII(col)) {
                result.warnings.push_back(
                    fmt::format("Column '{}' may contain PII. Consider anonymization.", col.name));
            }
        }
        
        // Check for explicit consent flag
        if (!schema.HasColumn("consent_flag")) {
            result.errors.push_back(
                "Missing 'consent_flag' column required for GDPR compliance.");
        }
        
        // Check for data retention policy metadata
        auto metadata = dataset->GetMetadata();
        if (!metadata.contains("retention_days")) {
            result.warnings.push_back(
                "Missing 'retention_days' metadata. GDPR requires data retention limits.");
        }
        
        return result;
    }
    
private:
    bool ContainsPII(const Column& col) {
        // Heuristic: check column name for common PII patterns
        std::regex pii_regex("(email|phone|ssn|ip_?address|credit_?card)", 
                             std::regex::icase);
        return std::regex_search(col.name, pii_regex);
    }
};
```

This analysis runs automatically when the user clicks the Analysis tab, and results appear alongside built-in statistics.

---

## Extension Point 4 — Custom Panels (IPanelProvider)

**Use Case:** Domain-specific tools that don't fit the node model (model comparison dashboard, experiment tracker, data drift monitor).

```cpp
// External plugin: plugins/monitoring/data_drift_panel.cpp

class DataDriftPanel : public IPanelProvider {
public:
    const char* GetPanelName() const override { return "Data Drift Monitor"; }
    
    void Render() override {
        ImGui::Text("Monitoring drift between train and production data");
        
        // Compare feature distributions
        auto train_data = DataRegistry::Instance().Get("train_set");
        auto prod_data  = DataRegistry::Instance().Get("production_logs");
        
        if (train_data && prod_data) {
            auto drift_score = ComputeDrift(train_data, prod_data);
            ImGui::Text("KL Divergence: %.4f", drift_score);
            
            if (drift_score > 0.1) {
                ImGui::TextColored({1,0,0,1}, "⚠ Significant drift detected!");
                if (ImGui::Button("Retrain Model"))
                    TriggerRetraining();
            }
        }
    }
    
private:
    float ComputeDrift(std::shared_ptr<BaseDataset> train, 
                       std::shared_ptr<BaseDataset> prod) {
        // KL divergence between feature distributions
        // ...
    }
};
```

This panel appears in the View menu as `Data Drift Monitor` and docks alongside other panels.

---

# PART 5 — IMPLEMENTATION ROADMAP

Now that the complete architecture is defined, here's the pragmatic 20-week implementation plan.

---

## Phase 1 — Foundation (Weeks 1–4)

**Deliverable:** DataRegistry + PipelineRegistry + basic GUI shell

### Tasks:
1. Implement DataRegistry (versioning, LRU, lineage tracking)
2. Implement PipelineRegistry (JSON serialization, hashing)
3. Create DataStudioPanel GUI container with 7-tab docking layout
4. Port existing panels into tabs:
   - AssetSidebar ← dataset_panel.cpp
   - DataEditor ← dataset_panel_interactive.cpp
   - ScriptTab ← scripting_engine.cpp
5. Integrate imgui-node-editor via vcpkg
6. Register panel in PanelRegistry (View menu, Ctrl+D)

**Success Criteria:**
- User can open Data Studio, see empty canvas, load CSV into Asset Sidebar, view in Data Editor
- DataRegistry stores loaded CSV with version tag `v1`
- Memory usage tracked, LRU eviction works (test with 20 GB dataset on 16 GB machine)

---

## Phase 2 — Node Abstraction Layer (Weeks 5–7)

**Deliverable:** DSNode interface + NodeRegistry + 10 basic nodes

### Tasks:
1. Define DSNode interface (Execute, RenderConfig, ports, etc.)
2. Implement NodeRegistry with plugin integration (INodeProvider)
3. Implement 10 core nodes:
   - **Input:** FileInput, DatabaseQuery
   - **Tabular:** FilterRows, SelectColumns, FillMissing, RemoveDuplicates
   - **Feature Eng:** StandardScale, OneHotEncode
   - **Output:** SaveDataset, ExportTraining
4. Integrate DuckDB for tabular operations (already in vcpkg.json)
5. Wrap Apache Arrow for zero-copy data transfer
6. Test node execution on AsyncTaskManager background threads

**Success Criteria:**
- User can drag FileInput node onto canvas, configure filepath in Properties Panel
- Connect FileInput → FilterRows → SaveDataset
- Pipeline executes successfully, shows per-node progress bars
- Final dataset appears in Asset Sidebar with new version tag

---

## Phase 3 — Multi-Modal Nodes (Weeks 8–13)

**Deliverable:** Complete 60-node catalogue covering all data types

### Tasks:
1. **Text nodes (6):** TextClean, Tokenize, Stem, StopWords, NGrams, TFIDF
   - Wrap tokenizer.cpp, integrate RE2, ICU, Snowball
2. **Image nodes (7):** Resize, Normalize, Augment, ColorSpace, Filter, Crop, Rotate
   - Wrap OpenCV (cv::resize, cv::cvtColor, cv::GaussianBlur, etc.)
3. **Audio nodes (6):** Resample, Trim, Normalize, MFCC, MelSpec, Spectrogram
   - Wrap audio_processing.cpp, libsndfile, FFTW3
4. **Video nodes (4):** FrameExtract, Resize, SceneDetect, OpticalFlow
   - Wrap FFmpeg libavcodec, OpenCV optical flow
5. **Time-Series nodes (5):** TSWindow, TSFeatures, TSLag, TSDiff, TSSplit
   - Wrap time_series.cpp
6. **Feature Eng nodes (8):** MinMaxScale, RobustScale, LabelEncode, PCA, FeatureSelect
   - Integrate ArrayFire for GPU acceleration
7. **Cloud nodes (2):** CloudImport (CyxCloud), KafkaConsumer
   - Integrate CyxCloud SDK, librdkafka

**Success Criteria:**
- All 7 domain workflows (CV, NLP, Audio, Video, TS, Tabular, Multi-modal) can be built
- Each workflow self-test passes (see Domain sections for specific tests)
- GPU acceleration works for image/audio batch operations (test on 10k images)

---

## Phase 4 — Analysis, Visualization & Annotation (Weeks 14–17)

**Deliverable:** Complete analysis/viz/annotation workflows

### Tasks:
1. **Analysis Tab:**
   - Wrap dataset_analyzer.cpp (12-thread parallel execution)
   - Integrate Isolation Forest C++ for outlier detection
   - Add GDPR/HIPAA compliance checks (example plugin)
2. **Visualization Tab:**
   - Wrap PlotWindow (ImPlot charts)
   - Add image gallery (OpenCV textures → ImGui images)
   - Add audio waveform viewer (Wavesurfer.js-style in ImGui)
   - Add spectrogram overlay (FFTW3 + ImPlot heatmap)
   - Add video frame strip viewer
3. **Annotate Tab:**
   - Wrap annotation_manager (bboxes, polygons, masks)
   - Add batch navigation (Prev/Next/Go-to with keyboard shortcuts)
   - Add auto-labeling via ONNX inference
   - Add COCO/YOLO/VOC export buttons
4. **Query Editor:**
   - Integrate ImGuiColorTextEdit (SQL syntax highlighting)
   - Connect to DuckDB instance
   - Add save-result-as-dataset button

**Success Criteria:**
- User loads 100k row CSV, clicks Analysis tab, sees full profiling report within 15s
- User loads 10k images, clicks Visualize tab, sees thumbnail gallery with smooth scrolling
- User annotates 200 images, exports COCO JSON, validates with pycocotools
- User writes DuckDB query, result appears as new dataset in Asset Sidebar

---

## Phase 5 — Deploy & Polish (Weeks 18–20)

**Deliverable:** Production-ready system, all self-tests passing

### Tasks:
1. **Export Wizard:**
   - Train/Val/Test split UI with stratification
   - Format picker (CSV, Parquet, NPZ, HDF5, TFRecord)
   - Version tagging input
   - CyxCloud upload with progress bar
2. **Deploy to Node Editor:**
   - Implement DatasetHandle passing to Model Builder
   - Visual confirmation (highlight DataInput node, glow effect)
   - Support multiple tensors (for multi-modal models)
3. **Remote Training:**
   - Integrate with P2PClient::SubmitJob()
   - Training Monitor panel (real-time metrics streaming)
   - Model download on completion
4. **Hybrid Mode:**
   - Side-by-side canvas + script layout
   - Bidirectional live sync (canvas change → script update, script change → canvas update)
5. **Keyboard Shortcuts:**
   - Ctrl+R: Run pipeline
   - Ctrl+S: Save pipeline
   - Ctrl+D: Open/close Data Studio
   - F: Fit canvas to screen
   - Del: Delete selected nodes
   - Ctrl+Z/Y: Undo/Redo
6. **Polish:**
   - Pipeline dry-run (preview without commit)
   - Node output streaming (Data Table updates row-by-row during execution)
   - Error recovery (resume pipeline from failed node)
   - Pipeline templates (pre-built common workflows)

**Success Criteria:**
- All 15 self-test scenarios pass (see Section 10 of v2 document)
- All 7 domain workflows execute successfully
- Performance targets met (see Section 12 of v2 document)
- User feedback: "feels like KNIME but faster and better integrated"

---

# PART 6 — FUTURE ROADMAP (Post-v1.0)

The architecture enables these future capabilities without structural changes:

---

## Year 2 Features

1. **AutoML Node Suggestions**
   - AI-powered recommendations in Analysis tab
   - "Class imbalance detected — suggest SMOTE node at position X"
   - "Correlation > 0.95 between features A and B — suggest dropping one"

2. **ONNX Inference Node**
   - Run ONNX models within pipeline for auto-labeling, feature extraction, filtering
   - Example: object detection model pre-annotates images, human corrects

3. **Federated Data Access**
   - Browse remote datasets without full download
   - Stream predictions directly from CyxCloud

4. **Data Lineage Graph Panel**
   - Visualize: which pipeline version produced which dataset version
   - Click dataset → see full provenance chain back to raw source

5. **Collaborative Annotation**
   - Multi-user annotation projects via CyxCloud
   - Conflict resolution, inter-annotator agreement scoring

6. **Blockchain Dataset Registry**
   - Register versioned datasets on Solana as provenance NFTs
   - Verifiable training data for decentralized compute network

7. **Vector Store Output Nodes**
   - Embedding nodes output to FAISS/Milvus for semantic search
   - Retrieval-augmented pipelines

8. **Model Feedback Loop**
   - Training results (confusion matrix, misclassified samples) fed back to Data Studio
   - Identify problematic data subsets for cleaning or re-annotation

---

## Year 3+ Research Directions

1. **Differential Privacy Nodes**
   - Add calibrated noise to datasets while preserving statistical properties
   - GDPR-compliant data sharing

2. **Synthetic Data Generation**
   - GAN-based augmentation for rare classes
   - Tabular data synthesis via VAE or diffusion models

3. **Active Learning Integration**
   - Model uncertainty → prioritize samples for annotation
   - Closed-loop: train model → annotate uncertain samples → retrain

4. **Causal Inference Nodes**
   - Identify causal relationships in observational data
   - Intervention simulation (what-if analysis)

5. **Explainability Dashboard**
   - SHAP/LIME explanations for black-box model predictions
   - Feature attribution overlaid on data visualizations

---

# CONCLUSION

CyxWiz Data Studio is **not** a data science tool for data scientists. It is **an ML engineering tool for ML engineers**.

It follows KNIME's proven seven-layer architecture — **but goes further** with:
- Native C++/GPU performance (10–100× faster than JVM-based tools)
- Multi-modal first-class support (not bolted on via extensions)
- Direct training handoff (one-click from clean data to active training)
- Decentralized compute integration (dataset provenance NFTs, P2P training)
- Crash-isolated plugin system (SafeExecute prevents studio crashes)

The architecture is designed for:
- **Consolidation:** Wraps existing CyxWiz modules rather than duplicating them
- **Extensibility:** Four plugin extension points (data loaders, nodes, panels, analytics)
- **Performance:** Background execution, LRU memory management, GPU acceleration
- **Reproducibility:** Deterministic pipeline hashing, version control, lineage tracking
- **Integration:** Deep integration with CyxWiz Engine, Node Editor, CyxCloud, P2P network

**The Bottom Line:**
Every data type an ML engineer encounters — tabular, text, image, audio, video, time-series, multi-modal — can be loaded, cleaned, transformed, analyzed, visualized, annotated, and deployed to training **inside a single workspace** using a **consistent interaction model** powered by a **robust, layered architecture** that **will scale for the next decade**.

This is the solid foundation you asked for.

---

**Next Steps:**
1. Review this architecture with the team
2. Approve or request modifications
3. Begin Phase 1 implementation (Weeks 1–4: Foundation)
4. Iterate on UX mockups for Pipeline Canvas and Properties Panel
5. Define API contracts for Layer 4 (BaseDataset, TabularDataset, etc.)
